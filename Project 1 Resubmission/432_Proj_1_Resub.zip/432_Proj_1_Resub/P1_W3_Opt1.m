comp_time = {};
labels = {};
J1 = 100;
J2 = 1;
b1 = 10;
b2 = 1;
count = 1;

for K = [10,100,1000]
    for solvers =["ode1","ode4","ode45"]
        for dt = ["0.1","1"]
            startTime = cputime;
            if solvers == "ode45"
                app_tau = 100;
                simout1 = sim("P1_W3_Opt1_Sim.slx","Solver",solvers);
                app_tau = 1;
                simout2 = sim("P1_W3_Opt1_Sim.slx","Solver",solvers);
                labels = cat(1, labels, solvers);
            else
                app_tau = 100;
                simout1 = sim("P1_W3_Opt1_Sim.slx","Solver",solvers);
                app_tau = 1;
                simout2 = sim("P1_W3_Opt1_Sim.slx","Solver",solvers);
                labels = cat(1, labels, solvers + ", dt = " + dt);
            end
            comp_time = cat(1, comp_time, cputime - startTime);
            time1 = simout1.tout;
            time2 = simout2.tout;
            omega1_1 = simout1.omega1.Data;
            omega2_1 = simout1.omega2.Data;
            omega1_2 = simout2.omega1.Data;
            omega2_2 = simout2.omega2.Data;
            subplot(3,4,count);
            hold on
            plot(time1,omega1_1);
            plot(time2,omega1_2);
            hold off
            title("K = " + K + " omega1, "+labels(end));
            xlabel("Time");
            ylabel("Speed of Shaft")
            legend("tau = 100","tau = 1")
            count = count + 1;
            subplot(3,4,count);
            hold on
            plot(time1,omega2_1);
            plot(time2,omega2_2);
            hold off
            title("K = " + K + " omega2, "+labels(end));
            xlabel("Time");
            ylabel("Speed of Shaft")
            legend("tau = 100","tau = 1")
            count = count + 1;
        end
    end
    if K == 1000;
        break
    else
        figure;
        count = 1;
    end
end