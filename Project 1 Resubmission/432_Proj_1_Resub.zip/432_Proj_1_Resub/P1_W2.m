comp_time = {};
labels = {};
max_error = {};
J = 100;
b = 10;
frequency = 0.1;
amp_tau = 100;
isSinWave = 1;
omega0 = 10;

for solvers = ["ode1","ode4"]
   for dt = [".001",".1","1"]
       startTime = cputime;
       simout = sim("P1_W2_Sim.slx","Solver",solvers,"FixedStep",dt);
       comp_time = cat(1, comp_time, cputime - startTime);
       labels = cat(1, labels, solvers + ", dt = " + dt);
       if isSinWave == 0
           omega = simout.omega.Data;
           t = simout.tout;
           len = length(omega);
           tt = linspace(0,25,len)';
           tomega = omega_theoretical(tt, amp_tau, b, omega0, J);
           max_error = cat(1, max_error, max(omega - tomega));
       else
           omega = simout.omega.Data;
           t = simout.tout;
           tomega = sinTheoretical(t);
           diff = omega - tomega;
           max_error = cat(1, max_error, max(omega - tomega));
       end
   end
end

for solvers = ["ode45","ode23tb"]
    startTime = cputime;
    simout = sim("P1_W2_Sim.slx","Solver",solvers);
    comp_time = cat(1, comp_time, cputime - startTime);
    labels = cat(1, labels, solvers);

    if isSinWave == 0
        omega = simout.omega.Data;
        t = simout.tout;
        len = length(omega);
        tt = linspace(0,25,len)';
        tomega = omega_theoretical(tt, amp_tau, b, omega0, J);
        max_error = cat(1, max_error, max(omega - tomega));
    else
        omega = simout.omega.Data;
        t = simout.tout;
        tomega = sinTheoretical(t);
        diff = omega - tomega;
        max_error = cat(1, max_error, max(omega - tomega));
    end
end

subplot(3,1,1)
bar(labels, cell2mat(max_error),'FaceColor', [1 0.647 0])
xlabel("Sim Settings")
ylabel("Error")
legend("Max Error")

subplot(3,1,2)
bar(labels, cell2mat(comp_time),'FaceColor', [0 0.4470 0.7410])
xlabel("Sim Settings")
ylabel("Comp Time")
legend("Comp Time")

subplot(3,1,3)
colors = [1 0.647 0; 0 0.4470 0.7410];
h = bar(labels, [cell2mat(max_error),cell2mat(comp_time)], 'grouped');
h(1).FaceColor = colors(1, :);
h(2).FaceColor = colors(2, :);
xlabel("Sim Settings")
yyaxis left;
ylabel("Comp Time")
yyaxis right;
ylabel("Max Error","Color",[1 0.647 0])
legend("Max Error","Comp Time")

function omega = omega_theoretical(t, tau, b, omega0, J)
    omega = (tau/b) * (1-exp(-b*t/J)) + omega0 * exp(-b*t/J);
end

function omega = sinTheoretical(t)
    simout = sim("P1_W2_Sim.slx","Solver","ode4","FixedStep",".001");
    omegat = simout.omega.Data;
    tt = simout.tout;
    omega = spline(tt,omegat,t);
end