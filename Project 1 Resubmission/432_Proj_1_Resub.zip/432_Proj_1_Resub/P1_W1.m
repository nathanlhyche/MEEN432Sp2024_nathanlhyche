J = 1;
b = 1;
tau = 1;
omega0 = 1;
count = 1;

for solvers = ["ode1","ode4"]
   for dt = [".001",".1","1"]

        simout = sim("P1_W1_Sim.slx","Solver",solvers,"FixedStep",dt);
        omega = simout.omega.Data;
        omegadot = simout.omegadot.Data;
        t = simout.tout;
        subplot(2,3,count);
        hold on;
        plot(t, omega);
        hold off;
        legend("omega");
        title("Solver"+ " = " + solvers + " + dt = " + dt);
        xlabel("Time")
        ylabel("Angular velocity (rad/s)")
        count = count + 1;
   end
end