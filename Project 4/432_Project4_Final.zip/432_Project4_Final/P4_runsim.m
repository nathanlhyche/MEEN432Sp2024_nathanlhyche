P4init;

path.l_st = 900;
path.width = 10;
path.radius = 200;

radius = path.radius;
length_of_straight = path.l_st;
width_of_track = path.width;

theta1 = linspace(3*pi/2, pi/2, 1000);  
x1 = radius * cos(theta1);
y1 = radius * sin(theta1);

theta2 = linspace(-pi/2, -3*pi/2, 1000);  
x2 = -radius * cos(theta2) + length_of_straight;
y2 = -radius * sin(theta2);

x3 = linspace(0,length_of_straight, 1000);  
y3 = -200*ones(size(x3));

x4 = linspace(length_of_straight,0, 1000);  
y4 = 200*ones(size(x4));

% Combine all sections
x = [x3,fliplr(x2), (x4), fliplr(x1)];
y = [y3,fliplr(y2), (y4), fliplr(y1)];
x = x - x(1);
y = y - y(1);

simout = sim('P4_sim_Final.slx', 'StopTime', '3600')
sim_vel = simout.vel.Data;
sim_time = simout.tout;
power = simout.power.data;
X = simout.X.Data;
Y = simout.Y.Data;


figure;
hold on
set(gca, 'Color', [.2, .48, .32]);
plot(x, y, 'LineWidth', 8,'Color',[ 0 0 0]);
xlim([-300, 1200]); 
ylim([-75, 500]);
hold off
title('Race Track');
xlabel('X-axis (meters)');
ylabel('Y-axis (meters)');
axis equal;  
race = raceStat(X,Y,sim_time,path,simout)


vehicle_length = 50;  
vehicle_width = 20;  
x_vehicle = [0, vehicle_length, vehicle_length, 0, 0];
y_vehicle = [-vehicle_width/2, -vehicle_width/2, vehicle_width/2, vehicle_width/2, -vehicle_width/2];
initial_orientation = 0;
vehicle_patch = patch('XData', x_vehicle, 'YData', y_vehicle, 'FaceColor', 'r', 'EdgeColor', 'k');

for i = 2:length(x)
    set(vehicle_patch, 'XData', x_vehicle + X(i), 'YData', y_vehicle + Y(i));
    if i > 2
        orientation = atan2(Y(i) - Y(i-1), X(i) - X(i-1));
    else
        orientation = atan2(Y(2) - Y(1), X(2) - X(1));
    end
    rotate(vehicle_patch, [0, 0, 1], rad2deg(orientation - initial_orientation), [X(i), Y(i), 0]);
    pause(0.001); 
end